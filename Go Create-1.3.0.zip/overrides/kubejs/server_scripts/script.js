// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

console.info('Hello, World! (You will see this line every time server resources reload)')

onEvent('recipes', event => {
	const multiSmelt = (output, input) => {
		event.smelting(output, input)
		event.blasting(output, input)
	  }
	  const multiCook = (output, input) => {
		event.smelting(output, input)
		event.smoking(output, input)
	  }
	// Change recipes here
	event.remove({mod: 'vanillahammers'})
	event.remove({mod: 'ironjetpacks'})
	event.remove({id: 'twilightforest:uncrafting_table'})
	event.remove({id: 'cc:claim_block'})
	//UNDERGARDEN CHANGES
	event.remove({id:'undergarden:catalyst'})
	event.shaped('undergarden:catalyst', [
	'GLG',
	'LRL',
	'GLG'],{
		
	G: 'minecraft:gold_ingot',
	L: 'eidolon:lead_ingot',
	R: 'minecraft:diamond'
	})
	//CREATE CHANGES
	event.shapeless('2x kubejs:blazing_sugar',['minecraft:sugar','create_stuff_additions:blazing_alloy'])
	event.remove({id:'create:compacting/blaze_cake'})
	event.recipes.create.compacting('create:blaze_cake_base',['#forge:eggs','kubejs:blazing_sugar','create:cinder_flour'])
	//CREATE CRAFTS&ADDITIONS CHANGES
	event.remove({id:'createaddition:crafting/connector_1'})
	event.shaped('4x createaddition:connector', [
	' B ',
	'ARA',
	'ARA'],{
		
	A: 'create:andesite_alloy',
	B: 'create:copper_nugget',
	R: 'createaddition:copper_rod'
	})
	event.remove({id:'createaddition:crafting/furnace_burner'})
	event.remove({id:'createaddition:crafting/charger'})
	event.shaped('createaddition:charger',[
	'B B',
	'CNC',
	'SAS'],{
		A:'kubejs:advanced_circuit',
		B: 'create:copper_nugget',
		C:'createaddition:capacitor',
		S:'create:brass_sheet',
	N:'create:brass_casing'})
	event.remove({id:'createaddition:mechanical_crafting/accumulator'})
	event.recipes.create.mechanical_crafting('createaddition:accumulator',[
	' C C ',
	'SPWPS',
	'SPBPS',
	'SPAPS'],{
		A:'kubejs:advanced_circuit',
		P:'createaddition:capacitor',
		W:'createaddition:gold_spool',
		C:'createaddition:connector',
		S:'create:brass_sheet',
	B:'create:brass_casing'})
	event.remove({id:'createaddition:mechanical_crafting/alternator'})
	event.recipes.create.mechanical_crafting('createaddition:alternator',[
	'  F  ',
	'SWWWS',
	'SWRWS',
	'SWPWS',
	'SWAWS'],{
		A:'kubejs:advanced_circuit',
		P:'createaddition:capacitor',
		W:'createaddition:copper_spool',
		R:'createaddition:iron_rod',
		S:'create:iron_sheet',
	F:'create:shaft'})
	event.remove({id:'createaddition:crafting/crude_burner'})
	event.shaped('createaddition:crude_burner',[
	' S ',
	'CTC',
	'CBC'],{
		
		B: 'minecraft:blast_furnace',
		
		S:'create:spout',
		T:'create:fluid_tank',
	C:'create:copper_casing'})
	//CUSTOM CREATE ADDITIONS
	
	event.shaped('4x kubejs:silicon_blend', [
	'QEQ',
	'ERE',
	'QEQ'],{
		
	E: 'byg:end_sand',
	Q: 'byg:quartzite_sand',
	R: 'create:refined_radiance'
	})
	
	event.recipes.create.mixing(Fluid.of('kubejs:molten_silicon',100),[
	'kubejs:silicon_blend']).superheated()
	
	event.recipes.create.filling('kubejs:silicon_wafer', [
	  'minecraft:nether_star',
	  Fluid.of('kubejs:molten_silicon')
	])
	
	event.recipes.create.mechanical_crafting('kubejs:microprocessor',[
	
	'  P  ',
	'HCSCH',
	' RRR '],{
		P:'kubejs:netherite_sheet',
		H:'create:shadow_steel',
		C:'kubejs:advanced_circuit',
		S:'kubejs:silicon_wafer',
	R:'twilightforest:knightmetal_ingot'})
	
	event.recipes.create.mechanical_crafting('kubejs:advanced_circuit',[
	
	' TTT ',
	'QCACQ',
	' WWW '],{
		T:'create:electron_tube',
		Q:'minecraft:quartz',
		C:'kubejs:integrated_circuit',
		A:'createaddition:capacitor',
	W:'createaddition:gold_wire'})
	
	event.recipes.create.pressing('kubejs:netherite_sheet',['minecraft:netherite_ingot'])
	
	//CUSTOM ORE PROCESSING
		event.recipes.create.crushing([
	  'kubejs:crushed_storagium_ore',
	  Item.of('2x kubejs:crushed_storagium_ore').withChance(0.3),
	  Item.of('undergarden:depthrock').withChance(0.1)],'kubejs:storagium_ore')

	  
	  multiSmelt('kubejs:storagium_ingot','kubejs:storagium_ore')
	  multiSmelt('kubejs:storagium_ingot','kubejs:crushed_storagium_ore')
	  event.recipes.create.splashing(['10x kubejs:storagium_nugget',Item.of('5x kubejs:storagium_nugget').withChance(0.5)],['kubejs:crushed_storagium_ore'])
	  event.shaped('kubejs:storagium_ingot', [
	'NNN',
	'NNN',
	'NNN'],{
		
	
	N: 'kubejs:storagium_nugget'
	})
	event.shapeless('9x kubejs:storagium_nugget',['kubejs:storagium_ingot'])
	//VANILLA HAMMER CHANGES
	event.recipes.create.mechanical_crafting('vanillahammers:iron_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:iron_ingot',
		B:'minecraft:iron_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	event.recipes.create.mechanical_crafting('vanillahammers:gold_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:gold_ingot',
		B:'minecraft:gold_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	event.recipes.create.mechanical_crafting('vanillahammers:diamond_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:diamond',
		B:'minecraft:diamond_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	event.recipes.create.mechanical_crafting('vanillahammers:emerald_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:emerald',
		B:'minecraft:emerald_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	 event.smithing('vanillahammers:netherite_hammer', 'vanillahammers:diamond_hammer', 'minecraft:netherite_ingot')
	event.recipes.create.mechanical_crafting('vanillahammers:fiery_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  S  ',
	'  S  '],{
		I:'twilightforest:fiery_ingot',
		B:'twilightforest:fiery_block',
		D:'create:mechanical_drill',
		S:'minecraft:blaze_rod'
	})
	//IRONCHEST CHANGES
	event.remove({id:'ironchest:chests/gold_diamond_chest'})
	event.remove({id:'ironchest:chests/silver_diamond_chest'})
	event.shaped('ironchest:diamond_chest', [
	'GDG',
	'DCD',
	'GDG'],{
	G: '#forge:glass',
	D: 'minecraft:diamond',
	C: 'ironchest:gold_chest'})
	//EIDOLON CHANGES
	event.remove({id:'eidolon:pewter_blend'})
	event.shapeless('2x eidolon:pewter_blend',['create:crushed_lead_ore','create:crushed_iron_ore'])
	//STORAGE RACKS CHANGES
	event.remove({id:'storageracks:stone_controller'})
	event.remove({id:'storageracks:iron_controller'})
	event.remove({id:'storageracks:gold_controller'})
	event.remove({id:'storageracks:emerald_controller'})
	event.remove({id:'storageracks:diamond_controller'})
	event.recipes.create.mechanical_crafting('storageracks:stone_controller',[
	' SSS ',
	' QTQ ',
	' NLN ',
	' QTQ ',
	' SSS '],{
		S:'minecraft:smooth_stone',
		Q:'minecraft:quartz',
		T:'create:electron_tube',
		N:'twilightforest:naga_scale',
	L:'minecraft:lectern'})
	event.recipes.create.mechanical_crafting('storageracks:iron_controller',[
	' IBI ',
	' QCQ ',
	' GLG ',
	' QCQ ',
	' IBI '],{
		I:'minecraft:iron_ingot',
		B:'minecraft:iron_block',
		Q:'minecraft:quartz_block',
		C:'kubejs:integrated_circuit',
		G:'ironjetpacks:iron_cell',
	L:'storageracks:stone_controller'})
	event.recipes.create.mechanical_crafting('storageracks:gold_controller',[
	' ABA ',
	' RIR ',
	' RLR ',
	' RIR ',
	' ABA '],{
		A:'eidolon:arcane_gold_block',
		B:'minecraft:gold_block',
		I:'ironjetpacks:gold_cell',
		R:'minecraft:blaze_rod',
		
		
		L:'storageracks:iron_controller'})
	event.smithing('storageracks:emerald_controller', 'storageracks:gold_controller', 'minecraft:emerald_block')
	event.smithing('storageracks:diamond_controller', 'storageracks:emerald_controller', 'minecraft:diamond_block')
	//OTHER CHANGES
	event.remove({id:'bountifulbaubles:gloves_digging_iron'})
	event.remove({id:'bountifulbaubles:gloves_digging_diamond'})
	event.shaped('bountifulbaubles:gloves_digging_iron', [
	' LD',
	' G ',
	'I  '],{
		I: 'minecraft:iron_ingot',
	G: 'alexsmobs:falconry_glove',
	D: 'create:mechanical_drill',
	L: 'transport:iron_rail'})
	event.shaped('bountifulbaubles:gloves_digging_diamond', [
	' DD',
	' GD',
	'A  '],{
		A: 'theabyss:aberythe_gem',
	D: 'minecraft:diamond',
	G: 'bountifulbaubles:gloves_digging_iron'
	})
	//IRONJETPACKS CHANGE
	event.remove({id:'create_stuff_additions:encased_jet_recipe'})
	
	event.shaped('ironjetpacks:strap',[
	'SNS'],{
		S:'betterendforge:leather_stripe',
	N:'minecraft:iron_nugget'})
	event.shaped('ironjetpacks:copper_jetpack', [
	'SPS',
	'SJS',
	'T T'],{
		S: 'create:copper_sheet',
	P: 'ironjetpacks:copper_capacitor',
	J: 'ironjetpacks:strap',
	T: 'ironjetpacks:copper_thruster'})
	event.shaped('ironjetpacks:copper_capacitor', [
	'SZS',
	'SZS',
	'SZS'],{
		S: 'create:copper_sheet',
	
	Z: 'ironjetpacks:copper_cell'})
	event.shaped('ironjetpacks:copper_cell', [
	' T ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	T: 'createaddition:copper_rod',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:copper_thruster', [
	'SVS',
	'SPS',
	'W W'],{
		S: 'create:copper_sheet',
	V: 'create:copper_valve_handle',
	P: 'create:spout',
	W: 'createaddition:copper_wire'})
	event.recipes.create.mechanical_crafting('ironjetpacks:iron_jetpack',[
	' RCR ',
	' SPS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:iron_rod',
		C:'kubejs:advanced_circuit',
		S:'create:iron_sheet',
		P:'ironjetpacks:iron_capacitor',
		J:'ironjetpacks:copper_jetpack',
		T:'ironjetpacks:iron_thruster'})
	event.shaped('ironjetpacks:iron_capacitor', [
	'TZT',
	'SZS',
	'SZS'],{
		S: 'create:iron_sheet',
	T:'createaddition:connector',
	Z: 'ironjetpacks:iron_cell'})
	event.shaped('ironjetpacks:iron_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	W: 'createaddition:iron_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:iron_thruster', [
	'SCS',
	'SZS',
	'S S'],{
		S: 'create:copper_sheet',
	Z: 'ironjetpacks:iron_cell',
	C: 'kubejs:integrated_circuit'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:gold_jetpack',[
	' RAR ',
	' PWP ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:gold_rod',
		A:'eidolon:gold_inlay',
		S:'create:golden_sheet',
		P:'ironjetpacks:gold_capacitor',
		W:'createaddition:gold_spool',
		J:'ironjetpacks:iron_jetpack',
		T:'ironjetpacks:gold_thruster'})
	event.shaped('ironjetpacks:gold_capacitor', [
	'TZT',
	'AZA',
	'SZS'],{
		S: 'create:golden_sheet',
	T:'minecraft:gold_ingot',
	A:'kubejs:advanced_circuit',
	Z: 'ironjetpacks:gold_cell'})
	event.shaped('ironjetpacks:gold_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:golden_sheet',
	W: 'createaddition:gold_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:gold_thruster', [
	'SRS',
	'SJS',
	'S S'],{
		S: 'create:golden_sheet',
	R: 'minecraft:blaze_rod',
	J: 'twilightforest:encased_fire_jet'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:diamond_jetpack',[
	' AUA ',
	' DPD ',
	' DJD ',
	' D D ',
	' T T '],{
		
		U:'theabyss:ignisithe_gem',
		A:'theabyss:aboranys_gem',
		D:'minecraft:diamond',
		P:'ironjetpacks:diamond_capacitor',
		J:'ironjetpacks:gold_jetpack',
		T:'ironjetpacks:diamond_thruster'})
	event.shaped('ironjetpacks:diamond_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'minecraft:diamond',
	
	Z: 'ironjetpacks:diamond_cell'})
	event.shaped('ironjetpacks:diamond_cell', [
	' R ',
	'SDS',
	' R '],{
		S: 'minecraft:diamond',
	D: 'createaddition:diamond_grit',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:diamond_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'minecraft:diamond',
	Z: 'ironjetpacks:diamond_cell',
	J: 'theabyss:aboranys_gem'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:netherite_jetpack',[
	' SPS ',
	' SCS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		C:'kubejs:microprocessor',
		S:'kubejs:netherite_sheet',
		P:'ironjetpacks:netherite_capacitor',
		J:'ironjetpacks:diamond_jetpack',
		T:'ironjetpacks:netherite_thruster'})
	event.shaped('ironjetpacks:netherite_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'kubejs:netherite_sheet',
	
	Z: 'ironjetpacks:netherite_cell'})
	event.smithing('ironjetpacks:netherite_cell', 'ironjetpacks:diamond_cell', 'minecraft:netherite_ingot')
	event.shaped('ironjetpacks:netherite_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'kubejs:netherite_sheet',
	Z: 'ironjetpacks:netherite_cell',
	J: 'betterendforge:eternal_crystal'
	})
	
	//CUSTOM FOOD 
	event.shaped('6x kubejs:drink_can', [
	'   ',
	'I I',
	' I '],{
		
	I: 'create:iron_sheet'
	})
	
	event.recipes.create.filling('kubejs:go_energy_green', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_green_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_blue', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_blue_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_pink', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_pink_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_purple', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_purple_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_red', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_red_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_yellow', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_yellow_fluid', 250)
	])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_green_fluid'), [
	Fluid.of('minecraft:water'),'kubejs:blazing_sugar','kubejs:flavor_blend'])
	event.shapeless('2x kubejs:flavor_blend',['simplefarming:ginger','minecraft:glowstone_dust'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_blue_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',500),Fluid.of('theabyss:areno',500)])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_purple_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid'),'minecraft:chorus_fruit'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_pink_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid'),'minecraft:sweet_berries','simplefarming:raspberries','simplefarming:strawberries'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_red_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',500),Fluid.of('create:tea',500)])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_yellow_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',750),Fluid.of('create:honey',250)])
	
	//BEES CHANGES
	event.remove({id:'resourcefulbees:centrifuge_controller'})
	event.remove({id:'resourcefulbees:elite_centrifuge_controller'})
	event.shaped('resourcefulbees:centrifuge_controller', [
	'CFC',
	'RAR',
	'CIC'],{
		A: 'kubejs:advanced_circuit',
		R: 'createaddition:iron_rod',
		C: 'resourcefulbees:centrifuge_casing',
		F: 'resourcefulbees:centrifuge',
	I: 'ironjetpacks:iron_capacitor'
	})
	event.shaped('resourcefulbees:elite_centrifuge_controller', [
	'CFC',
	'RAR',
	'CIC'],{
		A: 'kubejs:microprocessor',
		R: 'betterendforge:eternal_crystal',
		C: 'resourcefulbees:elite_centrifuge_casing',
		F: 'minecraft:netherite_block',
	I: 'resourcefulbees:centrifuge_controller'
	})
	//REFINED STORAGE CHANGES
	 event.replaceInput({}, 'refinedstorage:quartz_enriched_iron', 'kubejs:storagium_ingot')
	 event.replaceInput({}, 'refinedstorage:advanced_processor', 'kubejs:advanced_circuit')
	 event.replaceInput({}, 'refinedstorage:improved_processor', 'kubejs:integrated_circuit')
	  event.replaceInput({}, 'refinedstorage:basic_processor', 'create:electron_tube')
	 event.remove({id:'refinedstorage:basic_processor'})
	  event.remove({id:'refinedstorage:improved_processor'})
	 event.remove({id:'refinedstorage:advanced_processor'})
	  event.remove({id:'refinedstorage:raw_basic_processor'})
	  event.remove({id:'refinedstorage:raw_improved_processor'})
	 event.remove({id:'refinedstorage:raw_advanced_processor'})
	 event.remove({id:'refinedstorage:controller'})
	 event.shaped('refinedstorage:controller', [
	'CFC',
	'RAR',
	'CRC'],{
		A: 'storageracks:gold_controller',
		R: 'refinedstorage:silicon',
		C: 'kubejs:storagium_ingot',
		F: 'kubejs:advanced_circuit'
	
	})
	
	event.remove({id:'creativewirelesstransmitter:creative_wireless_transmitter'})
	 event.shaped('creativewirelesstransmitter:creative_wireless_transmitter', [
	'CAC',
	'UUU',
	'CAC'],{
		A: 'kubejs:microprocessor',
		
		C: 'refinedstorage:wireless_transmitter',
		U: 'refinedstorage:range_upgrade'
	
	})
	
	
	 event.shaped('refinedstorageaddons:creative_wireless_crafting_grid', [
	' I ',
	' A ',
	' R '],{
		A: 'kubejs:microprocessor',
		
		R: 'refinedstorageaddons:wireless_crafting_grid',
		I: 'twilightforest:knightmetal_ingot'
	
	})
	
	event.shaped('refinedstorage:creative_wireless_crafting_monitor', [
	' I ',
	' A ',
	' R '],{
		A: 'kubejs:microprocessor',
		
		R: 'refinedstorage:wireless_crafting_monitor',
		I: 'twilightforest:knightmetal_ingot'
	
	})
	//BUILDING GADGETS CHANGES
	event.remove({id:'buildinggadgets:gadget_building'})
	 event.shaped('buildinggadgets:gadget_building', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_exchanging'})
	 event.shaped('buildinggadgets:gadget_exchanging', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_copy_paste'})
	 event.shaped('buildinggadgets:gadget_copy_paste', [
	'SDS',
	'EIE',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		E: 'minecraft:emerald',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_destruction'})
	 event.shaped('buildinggadgets:gadget_destruction', [
	'SDS',
	'PIP',
	'SBS'],{
		I: 'kubejs:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		P: 'minecraft:ender_pearl',
		B: 'minecraft:stone_button'
	
	})
	//ABYSS CHANGES
	event.shaped('theabyss:dark_stone', [
	'SSS',
	'SIS',
	'SSS'],{
		
		S: 'theabyss:cobble_stone',
		
		I: 'theabyss:fusion_ore'
	
	})
	//CHUNKLOADERS CHANGES
	event.remove({id:'chunkloaders:basic_chunk_loader'})
	 event.shaped('chunkloaders:basic_chunk_loader', [
	'SOS',
	'OIO',
	'SOS'],{
		I: 'kubejs:integrated_circuit',
		
		S: 'create:iron_sheet',
		
		O: 'minecraft:obsidian'
	
	})
	event.remove({id:'chunkloaders:advanced_chunk_loader'})
	 event.shaped('chunkloaders:advanced_chunk_loader', [
	'SBS',
	'OIO',
	'SBS'],{
		I: 'chunkloaders:basic_chunk_loader',
		
		S: 'create:golden_sheet',
		B: 'minecraft:blaze_rod',
		O: 'kubejs:advanced_circuit'
	
	})
	event.remove({id:'chunkloaders:ultimate_chunk_loader'})
	 event.shaped('chunkloaders:ultimate_chunk_loader', [
	'SOS',
	'CIC',
	'SOS'],{
		I: 'chunkloaders:advanced_chunk_loader',
		C: 'betterendforge:eternal_crystal',
		S: 'create:brass_sheet',
		
		O: 'kubejs:advanced_circuit'
	
	})
	//1.2 RECIPIES
	event.recipes.create.mixing(Fluid.of('transport:steam',1000),[Fluid.of('minecraft:water')]).heated()
	event.recipes.create.mixing(Fluid.of('kubejs:syrup',250),[Fluid.of('minecraft:water',250),'minecraft:sugar'])
	event.recipes.create.mixing(Fluid.of('kubejs:caramel_syrup',1000),[Fluid.of('kubejs:syrup',500),Fluid.of('kubejs:caramel',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:chocolate_syrup',1000),[Fluid.of('kubejs:syrup',500),Fluid.of('create:chocolate',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:hot_chocolate',1000),[Fluid.of('kubejs:steamed_milk',750),Fluid.of('create:chocolate',250)])
	event.recipes.create.mixing(Fluid.of('kubejs:steamed_milk',1000),[Fluid.of('transport:steam',250),Fluid.of('create:milk',750)])
	event.recipes.create.mixing(Fluid.of('kubejs:milk_foam',1000),[Fluid.of('transport:steam',250),Fluid.of('create:milk',750)]).heated()
	event.recipes.create.mixing(Fluid.of('kubejs:espresso',250),[Fluid.of('transport:steam',250),'kubejs:ground_coffee'])
	event.recipes.create.mixing(Fluid.of('kubejs:latte',500),[Fluid.of('kubejs:steamed_milk',375),Fluid.of('kubejs:espresso',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:americano',500),[Fluid.of('minecraft:water',375),Fluid.of('kubejs:espresso',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:cappuccino',500),[Fluid.of('kubejs:latte',375),Fluid.of('kubejs:milk_foam',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:cortado',250),[Fluid.of('kubejs:espresso',125),Fluid.of('kubejs:milk_foam',125)])
	event.recipes.create.mixing(Fluid.of('kubejs:mocha',500),[Fluid.of('kubejs:cappuccino',250),Fluid.of('kubejs:hot_chocolate',250)])
	event.recipes.create.mixing(Fluid.of('kubejs:cortado',500),[Fluid.of('kubejs:espresso',125),Fluid.of('minecraft:water',375)])
	event.recipes.create.mixing(Fluid.of('kubejs:caramel_milkshake',500),['kubejs:caramel',Fluid.of('create:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:chocolate_milkshake',500),['create:bar_of_chocolate',Fluid.of('create:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:strawberry_milkshake',500),['simplefarming:strawberries',Fluid.of('create:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:banana_milkshake',500),['simplefarming:banana',Fluid.of('create:milk',500)])
	event.recipes.create.mixing(Fluid.of('kubejs:batter'), [
	Fluid.of('create:milk'),'minecraft:egg','create:wheat_flour'])
	event.recipes.create.mixing(Fluid.of('kubejs:mayo',500), [
	Fluid.of('createaddition:seed_oil',500),'minecraft:egg','simplefarming:vinegar'])
	event.recipes.create.mixing(Fluid.of('kubejs:carbonated_water',1000),[Fluid.of('minecraft:water',1000),'theabyss:thunder_nugget'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_fluid'), [
	Fluid.of('kubejs:carbonated_water'),'kubejs:blazing_sugar','kubejs:flavor_blend'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_raspberry_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'simplefarming:raspberries','undergarden:indigo_stew'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_apple_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'minecraft:apple','simplefarming:cherries'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_bolloom_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'endergetic:bolloom_fruit'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_melon_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'minecraft:melon_slice','simplefarming:honeydew','simplefarming:cantaloupe'])
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_fizz_root_fluid'),[
	Fluid.of('kubejs:go_energy_fizz_fluid'),'simplefarming:marshmallow_root','quark:root_item'])
	event.recipes.create.mixing('kubejs:butter', [
	Fluid.of('create:milk',125),'minecraft:gold_nugget'])
	event.recipes.create.mixing('kubejs:brownie_mix', [
	'minecraft:cocoa_beans','kubejs:butter','create:wheat_flour','minecraft:egg'])
	event.recipes.create.mixing('kubejs:caramel_brownie_mix', [
	'kubejs:brownie_mix','kubejs:caramel'])
	event.recipes.create.mixing('kubejs:pastry_dough', [
	'kubejs:butter','create:dough','minecraft:sugar'])
	event.recipes.create.mixing('kubejs:oat_mix', [
	Fluid.of('kubejs:syrup',125),'simplefarming:oat'])
	event.recipes.create.mixing('kubejs:apple_fritter', [
	Fluid.of('createaddition:seed_oil',125),'kubejs:coated_apple']).heated()
	event.recipes.create.mixing('kubejs:banana_fritter', [
	Fluid.of('createaddition:seed_oil',125),'kubejs:coated_banana']).heated()
	event.recipes.create.mixing('kubejs:fried_chicken', [
	Fluid.of('createaddition:seed_oil',125),'kubejs:coated_chicken']).heated()
	event.recipes.create.mixing('2x kubejs:fries', [
	Fluid.of('createaddition:seed_oil',125),'minecraft:potato']).heated()
	event.recipes.create.mixing('kubejs:donut', [
	Fluid.of('createaddition:seed_oil',125),Fluid.of('kubejs:batter',125)]).heated()
	event.shapeless('kubejs:porcelain',['minecraft:clay_ball','minecraft:bone_meal'])
	event.shapeless('kubejs:ice_in_glass',['kubejs:tall_glass','kubejs:crushed_ice'])
	event.shapeless('kubejs:fries_with_mayo',['kubejs:fries','kubejs:bottle_of_mayo'])
	event.shapeless('3x kubejs:empty_espresso_cup',['kubejs:porcelain'])
	event.shapeless('12x kubejs:ginger_biscuit',['simplefarming:ginger','kubejs:butter','create:wheat_flour','minecraft:sugar'])
	event.shapeless('8x kubejs:jam_slice',['simplefarming:jam','kubejs:butter','create:wheat_flour','minecraft:sugar'])
	event.shapeless('8x kubejs:rocky_road',['minecraft:cocoa_beans','kubejs:butter','create:wheat_flour','simplefarming:marshmallow'])
	event.shapeless('kubejs:potato_salad',['minecraft:potato','simplefarming:onion','kubejs:bottle_of_mayo','minecraft:bowl'])
	event.shapeless('kubejs:coronation_chicken',['simplefarming:curry_powder','minecraft:cooked_chicken','kubejs:bottle_of_mayo','minecraft:bread'])
	event.shapeless('kubejs:pasta_salad',['simplefarming:pasta','kubejs:bottle_of_mayo','simplefarming:tomato','simplefarming:corn'])
	event.recipes.create.milling(
	  'kubejs:ground_coffee',
	  'undergarden:roasted_underbeans')
	  event.recipes.create.milling(
	  '2x kubejs:crushed_ice',
	  'minecraft:ice')
	event.recipes.create.compacting('2x kubejs:croissant_pastry',['kubejs:pastry_dough'])
	event.recipes.create.compacting('4x kubejs:flapjack',['kubejs:oat_mix'])
	event.shaped('3x kubejs:empty_cup', [
	'   ',
	'P P',
	' P '],{
		
	
	P: 'kubejs:porcelain'
	})
	event.shaped('3x kubejs:tall_glass', [
	'   ',
	'P P',
	' P '],{
		
	
	P: 'minecraft:glass_pane'
	})
	event.shaped('kubejs:millionaire_shortbread', [
	'C',
	'A',
	'S'],{
	C: 'create:bar_of_chocolate',	
	A: 'kubejs:caramel',
	S: 'kubejs:shortbread'
	})
	event.shaped('2x solarflux:sp_3', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:integrated_circuit',
    S: 'create:iron_sheet',	
	L: 'solarflux:photovoltaic_cell_2',
	P: 'solarflux:sp_2'
	})
	event.shaped('2x solarflux:sp_4', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:advanced_circuit',
    S: 'create:brass_sheet',	
	L: 'solarflux:photovoltaic_cell_3',
	P: 'solarflux:sp_3'
	})
	event.shaped('4x solarflux:sp_5', [
	'LLL',
	'PCP',
	'PSP'],{
	C: 'kubejs:microprocessor',
    S: 'create:brass_block',	
	L: 'solarflux:photovoltaic_cell_4',
	P: 'solarflux:sp_4'
	})
	event.shaped('solarflux:photovoltaic_cell_4', [
	'LLL',
	'PCP',
	'ISI'],{
	C: 'betterendforge:eternal_crystal',
	 I: 'kubejs:integrated_circuit',	
    S: 'solarflux:photovoltaic_cell_3',	
	L: 'minecraft:blaze_powder',
	P: 'minecraft:glowstone_dust'
	})
	event.shaped('kubejs:go_energy_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_green'
	})
	event.shaped('kubejs:go_energy_blue_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_blue'
	})
	event.shaped('kubejs:go_energy_pink_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_pink'
	})
	event.shaped('kubejs:go_energy_red_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_red'
	})
	event.shaped('kubejs:go_energy_purple_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_purple'
	})
	event.shaped('kubejs:go_energy_yellow_crate', [
	'CCC',
	'CCC',
	'CCC'],{
	C: 'kubejs:go_energy_yellow'
	})
	event.recipes.create.filling('kubejs:hot_chocolate', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:hot_chocolate', 250)
	])
	event.recipes.create.filling('kubejs:cappuccino', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:cappuccino', 250)
	])
	event.recipes.create.filling('kubejs:mocha', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:mocha', 250)
	])
	event.recipes.create.filling('kubejs:americano', [
	  'kubejs:empty_cup',
	  Fluid.of('kubejs:americano', 250)
	])
	event.recipes.create.filling('kubejs:espresso', [
	  'kubejs:empty_espresso_cup',
	  Fluid.of('kubejs:espresso', 125)
	])
	event.recipes.create.filling('kubejs:cortado', [
	  'kubejs:empty_espresso_cup',
	  Fluid.of('kubejs:cortado', 125)
	])
	event.recipes.create.filling('kubejs:latte', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:latte', 250)
	])
	event.recipes.create.filling('kubejs:banana_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:banana_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:strawberry_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:strawberry_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:caramel_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:caramel_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:chocolate_milkshake', [
	  'kubejs:tall_glass',
	  Fluid.of('kubejs:chocolate_milkshake', 250)
	])
	event.recipes.create.filling('kubejs:iced_latte', [
	  'kubejs:ice_in_glass',
	  Fluid.of('kubejs:latte', 250)
	])
	event.recipes.create.filling('kubejs:iced_coffee', [
	  'kubejs:ice_in_glass',
	  Fluid.of('kubejs:americano', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_apple', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_apple_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_bolloom', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_bolloom_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_melon', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_melon_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_fizz_raspberry', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_fizz_raspberry_fluid', 250)
	])
	event.recipes.create.filling('kubejs:coated_apple', [
	  'minecraft:apple',
	  Fluid.of('kubejs:batter', 125)
	])
	event.recipes.create.filling('kubejs:coated_banana', [
	  'simplefarming:banana',
	  Fluid.of('kubejs:batter', 125)
	])
	event.recipes.create.filling('kubejs:coated_chicken', [
	  'minecraft:chicken',
	  Fluid.of('kubejs:batter', 125)
	])
	event.recipes.create.filling('kubejs:bottle_of_mayo', [
	  'minecraft:glass_bottle',
	  Fluid.of('kubejs:mayo', 250)
	])
	event.recipes.create.filling('kubejs:cappuccino_caramel', [
	  'kubejs:cappuccino',
	  Fluid.of('kubejs:caramel_syrup', 125)
	])
	event.recipes.create.filling('kubejs:latte_caramel', [
	  'kubejs:latte',
	  Fluid.of('kubejs:caramel_syrup', 125)
	])
	event.recipes.create.filling('kubejs:iced_latte_caramel', [
	  'kubejs:iced_latte',
	  Fluid.of('kubejs:caramel_syrup', 125)
	])
	event.recipes.create.filling('kubejs:cappuccino_chocolate', [
	  'kubejs:cappuccino',
	  Fluid.of('kubejs:chocolate_syrup', 125)
	])
	event.recipes.create.filling('kubejs:latte_chocolate', [
	  'kubejs:latte',
	  Fluid.of('kubejs:chocolate_syrup', 125)
	])
	event.recipes.create.filling('kubejs:iced_latte_chocolate', [
	  'kubejs:iced_latte',
	  Fluid.of('kubejs:chocolate_syrup', 125)
	])
	multiCook('kubejs:shortbread','kubejs:pastry_dough')
	multiCook('kubejs:croissant','kubejs:croissant_pastry')
	multiCook('kubejs:caramel','minecraft:sugar')
	multiCook('kubejs:brownie','kubejs:brownie_mix')
	multiCook('kubejs:caramel_brownie','kubejs:caramel_brownie_mix')
	
	event.recipes.create.mixing('2x eidolon:pewter_ingot', [
	'minecraft:iron_ingot','#forge:ingots/lead']).heated()
	
	//1.3 ADDITIONS
	event.recipes.create.mechanical_crafting('kubejs:integrated_circuit',[
	
	'  L  ',
	'DDADD',
	' NNN '],{
		L:'kubejs:lapis_sheet',
		N:'minecraft:gold_nugget',
		D:'minecraft:redstone',
		A:'create:polished_rose_quartz'
	})
	event.recipes.create.pressing('kubejs:lapis_sheet',['minecraft:lapis_lazuli'])
	event.recipes.create.mixing(Fluid.of('kubejs:enderic_acid',500), [
	  'betterendforge:ender_dust',
	  Fluid.of('minecraft:water',500)
	]).superheated()
	event.recipes.create.mixing('kubejs:impure_copper_dust', [
	  'create:crushed_copper_ore',
	  Fluid.of('kubejs:enderic_acid',250)
	])
	event.recipes.create.mixing('kubejs:impure_iron_dust', [
	  'create:crushed_iron_ore',
	  Fluid.of('kubejs:enderic_acid',250)
	])
	event.recipes.create.mixing('kubejs:impure_gold_dust', [
	  'create:crushed_gold_ore',
	  Fluid.of('kubejs:enderic_acid',250)
	])
	event.recipes.create.mixing('kubejs:impure_zinc_dust', [
	  'create:crushed_zinc_ore',
	  Fluid.of('kubejs:enderic_acid',250)
	])
	event.recipes.create.mixing('kubejs:impure_lead_dust', [
	  'create:crushed_lead_ore',
	  Fluid.of('kubejs:enderic_acid',250)
	])
	event.recipes.create.mixing('kubejs:impure_storagium_dust', [
	  'kubejs:crushed_storagium_ore',
	  Fluid.of('kubejs:enderic_acid',250)
	])
	event.recipes.create.mixing('kubejs:impure_brass_dust', [
	  'create:crushed_brass',
	  Fluid.of('kubejs:enderic_acid',250)
	])
	event.recipes.create.splashing(['19x create:brass_nugget',Item.of('11x create:brass_nugget').withChance(0.5)],['kubejs:impure_brass_dust'])
	event.recipes.create.splashing(['19x minecraft:iron_nugget',Item.of('11x minecraft:iron_nugget').withChance(0.5)],['kubejs:impure_iron_dust'])
	event.recipes.create.splashing(['19x create:copper_nugget',Item.of('11x create:copper_nugget').withChance(0.5)],['kubejs:impure_copper_dust'])
	event.recipes.create.splashing(['19x create:zinc_nugget',Item.of('11x create:zinc_nugget').withChance(0.5)],['kubejs:impure_zinc_dust'])
	event.recipes.create.splashing(['19x eidolon:lead_nugget',Item.of('11x eidolon:lead_nugget').withChance(0.5)],['kubejs:impure_lead_dust'])
	event.recipes.create.splashing(['19x kubejs:storagium_nugget',Item.of('11x kubejs:storagium_nugget').withChance(0.5)],['kubejs:impure_storagium_dust'])
	event.recipes.create.splashing(['19x minecraft:gold_nugget',Item.of('11x minecraft:gold_nugget').withChance(0.5)],['kubejs:impure_gold_dust'])
	event.recipes.create.crushing(
	  
	  Item.of('betterendforge:ender_dust').withChance(0.66)
	  ,'betterendforge:ender_shard')
	 event.remove({mod:'createchunkloading'})
	 event.shaped('createchunkloading:chunk_loader', [
	'GEG',
	'EIE',
	'GEG'],{
		I: 'chunkloaders:advanced_chunk_loader',
		G: 'minecraft:glass',
		E: 'minecraft:emerald'
	
	})
})

onEvent('item.tags', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})

onEvent('ftbquests.completed.56394B7592CE3CDC', event => {
	event.server.runCommandSilent(`clear ${event.player} patchouli:guide_book`)
})



