// priority: 0

settings.logAddedRecipes = true
settings.logRemovedRecipes = true
settings.logSkippedRecipes = false
settings.logErroringRecipes = true

console.info('Hello, World! (You will see this line every time server resources reload)')

onEvent('recipes', event => {
	// Change recipes here
	event.remove({mod: 'vanillahammers'})
	event.remove({mod: 'ironjetpacks'})
	event.remove({id: 'twilightforest:uncrafting_table'})
	//UNDERGARDEN CHANGES
	event.remove({id:'undergarden:catalyst'})
	event.shaped('undergarden:catalyst', [
	'GLG',
	'LRL',
	'GLG'],{
		
	G: 'minecraft:gold_ingot',
	L: 'eidolon:lead_ingot',
	R: 'minecraft:diamond'
	})
	//CREATE CHANGES
	event.shapeless('2x kubejs:blazing_sugar',['minecraft:sugar','create_stuff_additions:blazing_alloy'])
	event.remove({id:'create:compacting/blaze_cake'})
	event.recipes.create.compacting('create:blaze_cake_base',['#forge:eggs','kubejs:blazing_sugar','create:cinder_flour'])
	//CREATE CRAFTS&ADDITIONS CHANGES
	event.remove({id:'createaddition:crafting/connector_1'})
	event.shaped('4x createaddition:connector', [
	' B ',
	'ARA',
	'ARA'],{
		
	A: 'create:andesite_alloy',
	B: 'create:copper_nugget',
	R: 'createaddition:copper_rod'
	})
	event.remove({id:'createaddition:crafting/furnace_burner'})
	event.remove({id:'createaddition:crafting/charger'})
	event.shaped('createaddition:charger',[
	'B B',
	'CNC',
	'SAS'],{
		A:'kubejs:advanced_circuit',
		B: 'create:copper_nugget',
		C:'createaddition:capacitor',
		S:'create:brass_sheet',
	N:'create:brass_casing'})
	event.remove({id:'createaddition:mechanical_crafting/accumulator'})
	event.recipes.create.mechanical_crafting('createaddition:accumulator',[
	' C C ',
	'SPWPS',
	'SPBPS',
	'SPAPS'],{
		A:'kubejs:advanced_circuit',
		P:'createaddition:capacitor',
		W:'createaddition:gold_spool',
		C:'createaddition:connector',
		S:'create:brass_sheet',
	B:'create:brass_casing'})
	event.remove({id:'createaddition:mechanical_crafting/alternator'})
	event.recipes.create.mechanical_crafting('createaddition:alternator',[
	'  F  ',
	'SWWWS',
	'SWRWS',
	'SWPWS',
	'SWAWS'],{
		A:'kubejs:advanced_circuit',
		P:'createaddition:capacitor',
		W:'createaddition:copper_spool',
		R:'createaddition:iron_rod',
		S:'create:iron_sheet',
	F:'create:shaft'})
	event.remove({id:'createaddition:crafting/crude_burner'})
	event.shaped('createaddition:crude_burner',[
	' S ',
	'CTC',
	'CBC'],{
		
		B: 'minecraft:blast_furnace',
		
		S:'create:spout',
		T:'create:fluid_tank',
	C:'create:copper_casing'})
	//CUSTOM CREATE ADDITIONS
	
	event.shaped('4x kubejs:silicon_blend', [
	'QEQ',
	'ERE',
	'QEQ'],{
		
	E: 'byg:end_sand',
	Q: 'byg:quartzite_sand',
	R: 'create:refined_radiance'
	})
	
	event.recipes.create.mixing(Fluid.of('kubejs:molten_silicon',100),[
	'kubejs:silicon_blend']).superheated()
	
	event.recipes.create.filling('kubejs:silicon_wafer', [
	  'minecraft:nether_star',
	  Fluid.of('kubejs:molten_silicon')
	])
	
	event.recipes.create.mechanical_crafting('kubejs:microprocessor',[
	
	'  P  ',
	'HCSCH',
	' RRR '],{
		P:'kubejs:netherite_sheet',
		H:'create:shadow_steel',
		C:'kubejs:advanced_circuit',
		S:'kubejs:silicon_wafer',
	R:'quark:iron_rod'})
	
	event.recipes.create.mechanical_crafting('kubejs:advanced_circuit',[
	
	' TTT ',
	'QCACQ',
	' WWW '],{
		T:'create:electron_tube',
		Q:'minecraft:quartz',
		C:'create:integrated_circuit',
		A:'createaddition:capacitor',
	W:'createaddition:gold_wire'})
	
	event.recipes.create.pressing('kubejs:netherite_sheet',['minecraft:netherite_ingot'])
	
	//CUSTOM ORE PROCESSING
		event.recipes.create.crushing([
	  'kubejs:crushed_storagium_ore',
	  Item.of('2x kubejs:crushed_storagium_ore').withChance(0.3),
	  Item.of('undergarden:depthrock').withChance(0.1)],'kubejs:storagium_ore')

	  const multiSmelt = (output, input) => {
		event.smelting(output, input)
		event.blasting(output, input)
	  }
	  multiSmelt('kubejs:storagium_ingot','kubejs:storagium_ore')
	  multiSmelt('kubejs:storagium_ingot','kubejs:crushed_storagium_ore')
	  event.recipes.create.splashing(['10x kubejs:storagium_nugget',Item.of('5x kubejs:storagium_nugget').withChance(0.5)],['kubejs:crushed_storagium_ore'])
	  event.shaped('kubejs:storagium_ingot', [
	'NNN',
	'NNN',
	'NNN'],{
		
	
	N: 'kubejs:storagium_nugget'
	})
	event.shapeless('9x kubejs:storagium_nugget',['kubejs:storagium_ingot'])
	//VANILLA HAMMER CHANGES
	event.recipes.create.mechanical_crafting('vanillahammers:iron_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:iron_ingot',
		B:'minecraft:iron_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	event.recipes.create.mechanical_crafting('vanillahammers:gold_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:gold_ingot',
		B:'minecraft:gold_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	event.recipes.create.mechanical_crafting('vanillahammers:diamond_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:diamond',
		B:'minecraft:diamond_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	event.recipes.create.mechanical_crafting('vanillahammers:emerald_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  L  ',
	'  L  '],{
		I:'minecraft:emerald',
		B:'minecraft:emerald_block',
		D:'create:mechanical_drill',
		S:'minecraft:stick',
	L:'betterendforge:leather_wrapped_stick'})
	 event.smithing('vanillahammers:netherite_hammer', 'vanillahammers:diamond_hammer', 'minecraft:netherite_ingot')
	event.recipes.create.mechanical_crafting('vanillahammers:fiery_hammer',[
	'IBDBI',
	'IISII',
	'  S  ',
	'  S  ',
	'  S  '],{
		I:'twilightforest:fiery_ingot',
		B:'twilightforest:fiery_block',
		D:'create:mechanical_drill',
		S:'minecraft:blaze_rod'
	})
	//IRONCHEST CHANGES
	event.remove({id:'ironchest:chests/gold_diamond_chest'})
	event.remove({id:'ironchest:chests/silver_diamond_chest'})
	event.shaped('ironchest:diamond_chest', [
	'GDG',
	'DCD',
	'GDG'],{
	G: '#forge:glass',
	D: 'minecraft:diamond',
	C: 'ironchest:gold_chest'})
	//EIDOLON CHANGES
	event.remove({id:'eidolon:pewter_blend'})
	event.shapeless('2x eidolon:pewter_blend',['create:crushed_lead_ore','create:crushed_iron_ore'])
	//STORAGE RACKS CHANGES
	event.remove({id:'storageracks:stone_controller'})
	event.remove({id:'storageracks:iron_controller'})
	event.remove({id:'storageracks:gold_controller'})
	event.remove({id:'storageracks:emerald_controller'})
	event.remove({id:'storageracks:diamond_controller'})
	event.recipes.create.mechanical_crafting('storageracks:stone_controller',[
	' SSS ',
	' QTQ ',
	' NLN ',
	' QTQ ',
	' SSS '],{
		S:'minecraft:smooth_stone',
		Q:'minecraft:quartz',
		T:'create:electron_tube',
		N:'twilightforest:naga_scale',
	L:'minecraft:lectern'})
	event.recipes.create.mechanical_crafting('storageracks:iron_controller',[
	' IBI ',
	' QCQ ',
	' GLG ',
	' QCQ ',
	' IBI '],{
		I:'minecraft:iron_ingot',
		B:'minecraft:iron_block',
		Q:'minecraft:quartz_block',
		C:'create:integrated_circuit',
		G:'ironjetpacks:iron_cell',
	L:'storageracks:stone_controller'})
	event.recipes.create.mechanical_crafting('storageracks:gold_controller',[
	' ABA ',
	' RIR ',
	' RLR ',
	' RIR ',
	' ABA '],{
		A:'eidolon:arcane_gold_block',
		B:'minecraft:gold_block',
		I:'ironjetpacks:gold_cell',
		R:'minecraft:blaze_rod',
		
		
		L:'storageracks:iron_controller'})
	event.smithing('storageracks:emerald_controller', 'storageracks:gold_controller', 'minecraft:emerald_block')
	event.smithing('storageracks:diamond_controller', 'storageracks:emerald_controller', 'minecraft:diamond_block')
	//OTHER CHANGES
	event.remove({id:'bountifulbaubles:gloves_digging_iron'})
	event.remove({id:'bountifulbaubles:gloves_digging_diamond'})
	event.shaped('bountifulbaubles:gloves_digging_iron', [
	' LD',
	' G ',
	'I  '],{
		I: 'minecraft:iron_ingot',
	G: 'alexsmobs:falconry_glove',
	D: 'create:mechanical_drill',
	L: 'transport:iron_rail'})
	event.shaped('bountifulbaubles:gloves_digging_diamond', [
	' DD',
	' GD',
	'A  '],{
		A: 'theabyss:abyssdiamond',
	D: 'minecraft:diamond',
	G: 'bountifulbaubles:gloves_digging_iron'
	})
	//IRONJETPACKS CHANGE
	event.remove({id:'create_stuff_additions:encased_jet_recipe'})
	event.shaped('create_stuff_additions:encased_jet_chestplate', [
	'ISI',
	'WIW',
	'FPF'],{
		S: 'create:brass_sheet',
	P: 'ironjetpacks:strap',
	I: 'create:brass_ingot',
	W: 'create:cogwheel',
	F: 'create:encased_fan'})
	event.shaped('ironjetpacks:strap',[
	'SNS'],{
		S:'betterendforge:leather_stripe',
	N:'minecraft:iron_nugget'})
	event.shaped('ironjetpacks:copper_jetpack', [
	'SPS',
	'SJS',
	'T T'],{
		S: 'create:copper_sheet',
	P: 'ironjetpacks:copper_capacitor',
	J: 'create_stuff_additions:encased_jet_chestplate',
	T: 'ironjetpacks:copper_thruster'})
	event.shaped('ironjetpacks:copper_capacitor', [
	'SZS',
	'SZS',
	'SZS'],{
		S: 'create:copper_sheet',
	
	Z: 'ironjetpacks:copper_cell'})
	event.shaped('ironjetpacks:copper_cell', [
	' T ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	T: 'createaddition:copper_rod',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:copper_thruster', [
	'SVS',
	'SPS',
	'W W'],{
		S: 'create:copper_sheet',
	V: 'create:copper_valve_handle',
	P: 'create:spout',
	W: 'createaddition:copper_wire'})
	event.recipes.create.mechanical_crafting('ironjetpacks:iron_jetpack',[
	' RCR ',
	' SPS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:iron_rod',
		C:'kubejs:advanced_circuit',
		S:'create:iron_sheet',
		P:'ironjetpacks:iron_capacitor',
		J:'ironjetpacks:copper_jetpack',
		T:'ironjetpacks:iron_thruster'})
	event.shaped('ironjetpacks:iron_capacitor', [
	'TZT',
	'SZS',
	'SZS'],{
		S: 'create:iron_sheet',
	T:'createaddition:connector',
	Z: 'ironjetpacks:iron_cell'})
	event.shaped('ironjetpacks:iron_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:copper_sheet',
	W: 'createaddition:iron_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:iron_thruster', [
	'SCS',
	'SZS',
	'S S'],{
		S: 'create:copper_sheet',
	Z: 'ironjetpacks:iron_cell',
	C: 'create:integrated_circuit'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:gold_jetpack',[
	' RAR ',
	' PWP ',
	' SJS ',
	' S S ',
	' T T '],{
		
		R:'createaddition:gold_rod',
		A:'eidolon:gold_inlay',
		S:'create:golden_sheet',
		P:'ironjetpacks:gold_capacitor',
		W:'createaddition:gold_spool',
		J:'ironjetpacks:iron_jetpack',
		T:'ironjetpacks:gold_thruster'})
	event.shaped('ironjetpacks:gold_capacitor', [
	'TZT',
	'AZA',
	'SZS'],{
		S: 'create:golden_sheet',
	T:'quark:gold_button',
	A:'kubejs:advanced_circuit',
	Z: 'ironjetpacks:gold_cell'})
	event.shaped('ironjetpacks:gold_cell', [
	' W ',
	'SRS',
	' S '],{
		S: 'create:golden_sheet',
	W: 'createaddition:gold_wire',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:gold_thruster', [
	'SRS',
	'SJS',
	'S S'],{
		S: 'create:golden_sheet',
	R: 'minecraft:blaze_rod',
	J: 'twilightforest:encased_fire_jet'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:diamond_jetpack',[
	' AUA ',
	' DPD ',
	' DJD ',
	' D D ',
	' T T '],{
		
		U:'theabyss:ultraabyssdiamond',
		A:'theabyss:abyssdiamond',
		D:'minecraft:diamond',
		P:'ironjetpacks:diamond_capacitor',
		J:'ironjetpacks:gold_jetpack',
		T:'ironjetpacks:diamond_thruster'})
	event.shaped('ironjetpacks:diamond_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'minecraft:diamond',
	
	Z: 'ironjetpacks:diamond_cell'})
	event.shaped('ironjetpacks:diamond_cell', [
	' R ',
	'SDS',
	' R '],{
		S: 'minecraft:diamond',
	D: 'createaddition:diamond_grit',
	R: 'minecraft:redstone'})
	event.shaped('ironjetpacks:diamond_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'minecraft:diamond',
	Z: 'ironjetpacks:diamond_cell',
	J: 'theabyss:abyssfirediamond'
	})
	event.recipes.create.mechanical_crafting('ironjetpacks:netherite_jetpack',[
	' SPS ',
	' SCS ',
	' SJS ',
	' S S ',
	' T T '],{
		
		C:'kubejs:microprocessor',
		S:'kubejs:netherite_sheet',
		P:'ironjetpacks:netherite_capacitor',
		J:'ironjetpacks:diamond_jetpack',
		T:'ironjetpacks:netherite_thruster'})
	event.shaped('ironjetpacks:netherite_capacitor', [
	'DZD',
	'DZD',
	'DZD'],{
		D: 'kubejs:netherite_sheet',
	
	Z: 'ironjetpacks:netherite_cell'})
	event.smithing('ironjetpacks:netherite_cell', 'ironjetpacks:diamond_cell', 'minecraft:netherite_ingot')
	event.shaped('ironjetpacks:netherite_thruster', [
	' Z ',
	'SJS',
	'S S'],{
		S: 'kubejs:netherite_sheet',
	Z: 'ironjetpacks:netherite_cell',
	J: 'betterendforge:eternal_crystal'
	})
	
	//CUSTOM FOOD 
	event.shaped('6x kubejs:drink_can', [
	'   ',
	'I I',
	' I '],{
		
	I: 'create:iron_sheet'
	})
	
	event.recipes.create.filling('kubejs:go_energy_green', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_green_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_blue', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_blue_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_pink', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_pink_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_purple', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_purple_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_red', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_red_fluid', 250)
	])
	event.recipes.create.filling('kubejs:go_energy_yellow', [
	  'kubejs:drink_can',
	  Fluid.of('kubejs:go_energy_yellow_fluid', 250)
	])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_green_fluid'), [
	Fluid.of('minecraft:water'),'kubejs:blazing_sugar','kubejs:flavor_blend'])
	event.shapeless('2x kubejs:flavor_blend',['simplefarming:ginger','minecraft:glowstone_dust'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_blue_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',500),Fluid.of('theabyss:abyssdimwater',500)])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_purple_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid'),'minecraft:chorus_fruit'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_pink_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid'),'minecraft:sweet_berries','simplefarming:raspberries','simplefarming:strawberries'])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_red_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',500),Fluid.of('create:tea',500)])
	
	event.recipes.create.mixing(Fluid.of('kubejs:go_energy_yellow_fluid'),[
	Fluid.of('kubejs:go_energy_green_fluid',750),Fluid.of('create:honey',250)])
	
	//BEES CHANGES
	event.remove({id:'resourcefulbees:centrifuge_controller'})
	event.remove({id:'resourcefulbees:elite_centrifuge_controller'})
	event.shaped('resourcefulbees:centrifuge_controller', [
	'CFC',
	'RAR',
	'CIC'],{
		A: 'kubejs:advanced_circuit',
		R: 'createaddition:iron_rod',
		C: 'resourcefulbees:centrifuge_casing',
		F: 'resourcefulbees:centrifuge',
	I: 'ironjetpacks:iron_capacitor'
	})
	event.shaped('resourcefulbees:elite_centrifuge_controller', [
	'CFC',
	'RAR',
	'CIC'],{
		A: 'kubejs:microprocessor',
		R: 'betterendforge:eternal_crystal',
		C: 'resourcefulbees:elite_centrifuge_casing',
		F: 'minecraft:netherite_block',
	I: 'resourcefulbees:centrifuge_controller'
	})
	//REFINED STORAGE CHANGES
	 event.replaceInput({}, 'refinedstorage:quartz_enriched_iron', 'kubejs:storagium_ingot')
	 event.replaceInput({}, 'refinedstorage:advanced_processor', 'kubejs:advanced_circuit')
	 event.replaceInput({}, 'refinedstorage:improved_processor', 'create:integrated_circuit')
	  event.replaceInput({}, 'refinedstorage:basic_processor', 'create:electron_tube')
	 event.remove({id:'refinedstorage:basic_processor'})
	  event.remove({id:'refinedstorage:improved_processor'})
	 event.remove({id:'refinedstorage:advanced_processor'})
	  event.remove({id:'refinedstorage:raw_basic_processor'})
	  event.remove({id:'refinedstorage:raw_improved_processor'})
	 event.remove({id:'refinedstorage:raw_advanced_processor'})
	 event.remove({id:'refinedstorage:controller'})
	 event.shaped('refinedstorage:controller', [
	'CFC',
	'RAR',
	'CRC'],{
		A: 'storageracks:gold_controller',
		R: 'refinedstorage:silicon',
		C: 'kubejs:storagium_ingot',
		F: 'kubejs:advanced_circuit'
	
	})
	
	event.remove({id:'creativewirelesstransmitter:creative_wireless_transmitter'})
	 event.shaped('creativewirelesstransmitter:creative_wireless_transmitter', [
	'CAC',
	'UUU',
	'CAC'],{
		A: 'kubejs:microprocessor',
		
		C: 'refinedstorage:wireless_transmitter',
		U: 'refinedstorage:range_upgrade'
	
	})
	
	
	 event.shaped('refinedstorageaddons:creative_wireless_crafting_grid', [
	' I ',
	' A ',
	' R '],{
		A: 'kubejs:microprocessor',
		
		R: 'refinedstorageaddons:wireless_crafting_grid',
		I: 'quark:iron_rod'
	
	})
	
	event.shaped('refinedstorage:creative_wireless_crafting_monitor', [
	' I ',
	' A ',
	' R '],{
		A: 'kubejs:microprocessor',
		
		R: 'refinedstorage:wireless_crafting_monitor',
		I: 'quark:iron_rod'
	
	})
	//BUILDING GADGETS CHANGES
	event.remove({id:'buildinggadgets:gadget_building'})
	 event.shaped('buildinggadgets:gadget_building', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'create:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_exchanging'})
	 event.shaped('buildinggadgets:gadget_exchanging', [
	'SDS',
	'SIS',
	'SBS'],{
		I: 'create:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_copy_paste'})
	 event.shaped('buildinggadgets:gadget_copy_paste', [
	'SDS',
	'EIE',
	'SBS'],{
		I: 'create:integrated_circuit',
		D: 'minecraft:dropper',
		S: 'create:iron_sheet',
		E: 'minecraft:emerald',
		B: 'minecraft:stone_button'
	
	})
	event.remove({id:'buildinggadgets:gadget_destruction'})
	 event.shaped('buildinggadgets:gadget_destruction', [
	'SDS',
	'PIP',
	'SBS'],{
		I: 'create:integrated_circuit',
		D: 'minecraft:dispenser',
		S: 'create:iron_sheet',
		P: 'minecraft:ender_pearl',
		B: 'minecraft:stone_button'
	
	})
	//ABYSS CHANGES
	event.shaped('theabyss:dark_stone', [
	'SSS',
	'SIS',
	'SSS'],{
		
		S: 'theabyss:abyssbrokenstone',
		
		I: 'theabyss:fusionore'
	
	})
	//CHUNKLOADERS CHANGES
	event.remove({id:'chunkloaders:basic_chunk_loader'})
	 event.shaped('chunkloaders:basic_chunk_loader', [
	'SOS',
	'OIO',
	'SOS'],{
		I: 'create:integrated_circuit',
		
		S: 'create:iron_sheet',
		
		O: 'minecraft:obsidian'
	
	})
	event.remove({id:'chunkloaders:advanced_chunk_loader'})
	 event.shaped('chunkloaders:advanced_chunk_loader', [
	'SBS',
	'OIO',
	'SBS'],{
		I: 'chunkloaders:basic_chunk_loader',
		
		S: 'create:golden_sheet',
		B: 'minecraft:blaze_rod',
		O: 'kubejs:advanced_circuit'
	
	})
	event.remove({id:'chunkloaders:ultimate_chunk_loader'})
	 event.shaped('chunkloaders:ultimate_chunk_loader', [
	'SOS',
	'CIC',
	'SBS'],{
		I: 'chunkloaders:basic_chunk_loader',
		C: 'betterendforge:eternal_crystal',
		S: 'create:brass_sheet',
		B: 'minecraft:diamond_block',
		O: 'kubejs:microprocessor'
	
	})
})

onEvent('item.tags', event => {
	// Get the #forge:cobblestone tag collection and add Diamond Ore to it
	// event.get('forge:cobblestone').add('minecraft:diamond_ore')

	// Get the #forge:cobblestone tag collection and remove Mossy Cobblestone from it
	// event.get('forge:cobblestone').remove('minecraft:mossy_cobblestone')
})

