// priority: 0

console.info('Hello, World! (You will only see this line once in console, during startup)')

onEvent('item.registry', event => {
	// Register new items here
	//event.create('example_item').displayName('Example Item')
	//CUSTOM CREATE ITEMS
	event.create('blazing_sugar').displayName('Blazing Sugar')
	event.create('advanced_circuit').displayName('§cAdvanced Circuit')
	event.create('microprocessor').displayName('§dMicroprocessor')
	event.create('silicon_blend').displayName('Silicon Blend')
	event.create('silicon_wafer').displayName('§eSilicon Wafer').glow(true)
	event.create('netherite_sheet').displayName('Netherite Sheet')
	
	event.create('storagium_ingot').displayName('Storagium Ingot')
	event.create('storagium_nugget').displayName('Storagium Nugget')
	event.create('crushed_storagium_ore').displayName('Crushed Storagium Ore')
	//CUSTOM FOODS
	event.create('drink_can').displayName('Drink Can')
	event.create('flavor_blend').displayName('Flavor Blend')	
	
	event.create('go_energy_green').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 180 1`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§aGo Energy Original')
	event.create('go_energy_blue').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:levitation 2 0`);e.server.runCommandSilent(`effect give ${e.player} minecraft:jump_boost 120 0`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§bGo Energy Diet')
	event.create('go_energy_pink').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:strength 120 0`);e.server.runCommandSilent(`effect give ${e.player} minecraft:regeneration 30 1`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§5Go Energy Mixed Berry')
	event.create('go_energy_purple').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:absorption 60 4`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§dGo Energy Chorus Punch')	
	event.create('go_energy_red').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:haste 180 0`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§eGo Energy Tea')	
	event.create('go_energy_yellow').food(food=>{food.hunger(6).saturation(1).eaten(e=> {e.server.runCommandSilent(`effect give ${e.player} minecraft:speed 120 0`); e.server.runCommandSilent(`effect give ${e.player} minecraft:health_boost 60 2`); e.server.runCommandSilent(`give ${e.player} kubejs:drink_can`)})}).displayName('§6Go Energy Honey Splash')	
	
})

onEvent('block.registry', event => {
	// Register new blocks here
	 event.create('storagium_ore').material('rock').hardness(2.0).displayName('Storagium Ore')
})

onEvent('fluid.registry', event => {
	// Register new blocks here
	// event.create('example_block').material('wood').hardness(1.0).displayName('Example Block')
	event.create('go_energy_green_fluid').textureThin(0xD1A504).displayName('Go Energy Original').bucketColor(0xD1A504)
	event.create('go_energy_blue_fluid').textureThin(0x6FE3B1).displayName('Go Energy Diet').bucketColor(0x6FE3B1)
	event.create('go_energy_pink_fluid').textureThin(0x9C0225).displayName('Go Energy Mixed Berry').bucketColor(0x9C0225)
	event.create('go_energy_purple_fluid').textureThin(0xCC96FF).displayName('Go Energy Chorus Punch').bucketColor(0xCC96FF)
	event.create('go_energy_red_fluid').textureThin(0x826400).displayName('Go Energy Tea').bucketColor(0x826400)
	event.create('go_energy_yellow_fluid').textureThin(0xDBD000).displayName('Go Energy Honey Splash').bucketColor(0xDBD000)
	event.create('molten_silicon').textureThick(0xFBFFAB).displayName('Molten Silicon').bucketColor(0xFBFFAB)
})

onEvent('item.tooltip', tooltip => {
	 tooltip.add(['create:copper_ore', 'create:zinc_ore', 'eidolon:lead_ore'], '§7Only found in the Twilight Forest')
})

onEvent('jei.hide.items', event => {
  event.hide('betterendforge:pearlberry_seed')

   })

onEvent('item.tags', event => {
  event.add('forge:workbench', 'minecraft:crafting_table')
  
})